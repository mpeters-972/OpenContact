import subprocess

subprocess.call(["C:\Program Files\Microsoft Office\Office11\Excel.exe","C:\Users\alex\Documents\Dr Peters\python\testafter.pcr"])
