import os

s1 ="protA: C:/Users/alex/Documents/Dr Peters/prota.pdb"
s2 = "protB: C:/Users/alex/Documents/Dr Peters/protb.pdb"
print s1.split('/')
print os.sep
